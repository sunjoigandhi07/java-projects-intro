import java.util.Arrays; 

public class Algorithms {
	
	public static boolean algOne(int [] n) {
		
		for(int i = 0; i < n.length-1; i++) {
			for(int j= n.length-1; j > 0; j--) { 
				if(n[i] == -n[j]) {
					return true; 
				}
			}
		}
		return false; 
	}
	
	public static boolean binarySearch(int [] n, int x) {
		int first = 0; 
		int last = n.length -1; 
		
		do {
			int middle = (first + last)/2;
			if(n[middle]== x) {
				return true;
			} else if (x < n[middle]) {
				last = middle -1;
			} else {
				first = middle +1; 
			}
		} 
		while (first <= last); 
		
		return false; 
	}
	
	public static boolean algTwo(int []n) {
		for(int i = 0; i< n.length-1; i++) {
			if(binarySearch(n,  -n[i])) {
				return true; 
			}
		}
		return false; 
	}
	
	public static boolean algThree(int [] n) {
		int j = n.length-1; 
		int i = 0;
		
			while(i !=j) {
				int sum = n[i] + n[j]; 
				if (sum == 0) {
					return true;
				}
				else if (sum > 0) {
					j--;
				}else {
					i++;
				}
			}
		return false; 
	}
	
	public static int[] generateSortedArray(int n) {
		//create a new array with size n 
		int [] array = new int[n]; 
		
		//fill array with random values from -100 through 100
		for(int i = 0; i < n; i++) {
			array[i] = (int)(Math.random() * 200) - 100; 
			while(array[i] == 0) {
				array[i] = (int)(Math.random() * 100) + 1; 
			}
		}
		Arrays.sort(array);
		
		return array; 
	}
}
