import java.util.Arrays; 

public class Driver {

	public static void main(String[] args) {
		testAlgOne();
	}
	
	
	//test Alg One
	public static void testAlgOne() {
		double numTrials = 1000000000; 
		System.out.println("N \tElapsed \tTime"); 
		for(int n = 50000; n <= 800000; n +=50000) {
			long start = System.currentTimeMillis();
			int [] test1 = Algorithms.generateSortedArray(n); 
			for(int i = 1; i <= numTrials; i++) { 
				Algorithms.algOne(test1);
			} 
			long end = System.currentTimeMillis(); 
			long time = (end - start);  
			
			System.out.println(n + "\t"+ time + "\t" + (time/numTrials)); 
		}
	}
}