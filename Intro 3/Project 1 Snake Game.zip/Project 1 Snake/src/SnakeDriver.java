
public class SnakeDriver {
	public static void main(String [] args) {
	
	Game play = new Game(); 
	
	}
}
