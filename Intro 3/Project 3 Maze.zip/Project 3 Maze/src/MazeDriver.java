public class MazeDriver {

	public static void main(String[] args) {
		Maze maze = new Maze(31, 31);
		maze.generateMaze();
		maze.solveMaze();
	}
}
