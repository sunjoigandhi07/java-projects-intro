public class LinkedListQueue<T> implements Queue<T> {

	private DoublyLinkedList<T> theQueue;
	
	public LinkedListQueue() {
		theQueue = new DoublyLinkedList<>();
	}
	@Override
	public void enqueue(T v) {
		theQueue.addLast(v);
	}

	@Override
	public T dequeue() {
		return theQueue.removeFirst();
	}

	@Override
	public T first() {
		return theQueue.get(0);
	}

	@Override
	public int size() {
		return theQueue.size();
	}

	@Override
	public boolean isEmpty() {
		return theQueue.isEmpty();
	}
	
	public String toString() {
		return theQueue.toString();
	}

}
