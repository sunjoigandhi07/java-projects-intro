import java.util.ArrayList;
import java.util.Collections;

import edu.du.dudraw.DUDraw;

public class Maze{
	
	//Cells can be wall, open, or explored
	public enum CellValue {WALL, OPEN, EXPLORED};

	//Stores the values of cells at each x and y position
	private CellValue[][] value;

	//Stores width and height of canvas
	private int width;
	private int height;

	public Maze(int w, int h) {

		width = w;
		height = h;

		DUDraw.setCanvasSize(500, 500);
		DUDraw.setXscale(0, width);
		DUDraw.setYscale(0, height);

		DUDraw.enableDoubleBuffering();

		//Create cells to fill up the canvas
		value = new CellValue[width][height];

		for(int i = 0; i < width; i ++) {
			for(int j = 0; j < height; j++) {
				//Initialize all cells to WALL to start
				value[i][j] = CellValue.WALL;
			}
		}
	}

	public void draw() {
		DUDraw.clear();
		
		//For each cell on the canvas
		for(int i = 0; i < value.length; i++) {
			for(int j = 0; j < value[0].length; j++) {
				
				//If the cell is a wall, color it black
				if(value[i][j] == CellValue.WALL) {
					DUDraw.setPenColor(DUDraw.BLACK);
				}
				
				//If the cell is open, color it white
				else if(value[i][j] == CellValue.OPEN) {
					DUDraw.setPenColor(DUDraw.WHITE);
				}
				
				//If the cell is explored, color it green
				else if(value[i][j] == CellValue.EXPLORED) {
					DUDraw.setPenColor(DUDraw.GREEN);
				}
				DUDraw.filledRectangle(i+0.5, j+0.5, 0.5, 0.5);
			}
		}
		DUDraw.show();
		DUDraw.pause(10);
	}

	public void generateMaze() {
		Cell currentCell = new Cell(1, 1);
		
		//Open the currentCell
		value[currentCell.column][currentCell.row] = CellValue.OPEN;

		//Create a stack to store the cells, and add currentCell to the stack
		LinkedListStack<Cell> cellStack = new LinkedListStack<>();
		cellStack.push(currentCell);

		while(!cellStack.isEmpty()) {
			
			//currentCell gets the top cell on the stack
			currentCell = cellStack.pop();

			//Stores the neighbors of the currentCell
			ArrayList<Cell> neighbors = new ArrayList<>();

			Cell north;
			Cell east;
			Cell west;
			Cell south;

			//North
			if(currentCell.row+2 < height && value[currentCell.column][currentCell.row+2] == CellValue.WALL) {
				north = new Cell(currentCell.column, currentCell.row+2);
				value[north.column][north.row] = CellValue.OPEN;
				value[north.column][north.row-1] = CellValue.OPEN;
				neighbors.add(north);
			}

			//East 
			if(currentCell.column+2 < width && value[currentCell.column+2][currentCell.row] == CellValue.WALL) {
				east = new Cell(currentCell.column+2, currentCell.row);
				value[east.column][east.row] = CellValue.OPEN;
				value[east.column-1][east.row] = CellValue.OPEN;
				neighbors.add(east);
			}

			//South 
			if(currentCell.row-2 >= 0 && value[currentCell.column][currentCell.row-2] == CellValue.WALL) {
				south = new Cell(currentCell.column, currentCell.row-2);
				value[south.column][south.row] = CellValue.OPEN;
				value[south.column][south.row+1] = CellValue.OPEN;
				neighbors.add(south);
			}

			//West 
			if(currentCell.column-2 >= 0 && value[currentCell.column-2][currentCell.row] == CellValue.WALL) {
				west = new Cell(currentCell.column-2, currentCell.row);
				value[west.column][west.row] = CellValue.OPEN;
				value[west.column+1][west.row] = CellValue.OPEN;
				neighbors.add(west);
			}

			//Shuffles the order of the neighbors so they get randomly added onto the stack
			Collections.shuffle(neighbors);

			for(int i = 0; i < neighbors.size(); i++) {
				cellStack.push(neighbors.get(i));
			}

			draw();
		}

	}

	public void solveMaze() {
		Cell start = new Cell(1, 1);
		Cell goal = new Cell(this.width-2, this.height-2);

		//Start the exploration at the start of the maze
		Cell currentCell = start;

		value[currentCell.column][currentCell.row] = CellValue.EXPLORED;

		//Create a Queue to add explored cells onto
		LinkedListQueue<Cell> cellQueue = new LinkedListQueue<>();
		cellQueue.enqueue(currentCell);

		while(!cellQueue.isEmpty()) {
			
			//currentCell gets the first cell added to the queue
			currentCell = cellQueue.dequeue();

			//If the currentCell is equal to the goal cell, end the exploration
			if(currentCell.row == goal.row && currentCell.column == goal.column) {
				return;
			}


			//North 
			if(currentCell.row+1 < height && value[currentCell.column][currentCell.row+1] != CellValue.EXPLORED 
					&& value[currentCell.column][currentCell.row+1] != CellValue.WALL) {
				Cell north = new Cell(currentCell.column, currentCell.row+1);
				cellQueue.enqueue(north);
				value[north.column][north.row] = CellValue.EXPLORED;
			}

			//East 
			if(currentCell.column+1 < width && value[currentCell.column+1][currentCell.row] != CellValue.EXPLORED 
					&& value[currentCell.column+1][currentCell.row] != CellValue.WALL) {
				Cell east = new Cell(currentCell.column+1, currentCell.row);
				cellQueue.enqueue(east);
				value[east.column][east.row] = CellValue.EXPLORED;
			}

			//South 
			if(currentCell.row-1 >= 0 && value[currentCell.column][currentCell.row-1] != CellValue.EXPLORED 
					&& value[currentCell.column][currentCell.row-1] != CellValue.WALL) {
				Cell south = new Cell(currentCell.column, currentCell.row-1);
				cellQueue.enqueue(south);
				value[south.column][south.row] = CellValue.EXPLORED;
			}

			//West 
			if(currentCell.column-1 >= 0 && value[currentCell.column-1][currentCell.row] != CellValue.EXPLORED 
					&& value[currentCell.column-1][currentCell.row] != CellValue.WALL) {
				Cell west = new Cell(currentCell.column-1, currentCell.row);
				cellQueue.enqueue(west);
				value[west.column][west.row] = CellValue.EXPLORED;
			}
			draw();
		}
	}

	public class Cell {
		private int row;
		private int column;

		public Cell(int c, int r) {
			row = r;
			column = c;
		}

		public String toString() {
			return "[" + column + ", " + row + "]";
		}
	}
}