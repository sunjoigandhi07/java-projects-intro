import java.util.NoSuchElementException;

public class DoublyLinkedList<T> {
	
	private int size;
	private Node header;
	private Node trailer;
	
	public DoublyLinkedList() {
		header = new Node(null);
		trailer = new Node(null);
		
		header.next = trailer;
		trailer.prev = header;
		
		size = 0;
	}
	
	public void addFirst(T v) throws IllegalArgumentException {
		addBetween(header, header.next, v);
	}
	
	public void addLast(T v) throws IllegalArgumentException {
		addBetween(trailer.prev, trailer, v);
	}
	
	public T removeFirst() {
		T value = header.next.value;
		removeBetween(header, header.next.next);
		return value;
	}
	
	public void removeLast() {
		removeBetween(trailer.prev.prev, trailer);
	}
	
	public int size() {
		return size;
	}
	
	public boolean isEmpty() {
		if(header == null) {
			return true;
		}
		return false;
	}
	
	public T get(int i) {
		if(header == null) {
			throw new NoSuchElementException();
		}
		if(i > size-1 || i < 0) {
			throw new IndexOutOfBoundsException();
		}
		
		Node temp = header;
		T value = null;
		int index = 0;
		
		while(index < i) {
			temp = temp.next;
			index++;
		}
		
		if(index == i) {
			value = temp.value;
		}
		
		return value;
		
	}
	
	public String toString() {
		String r = "List: ";
		Node current = header.next;
	
		
		while(current != trailer) {
			r += current + " ";
			current = current.next;
		}
		
		return r;
	}
	
	public String reverseToString() {
		String r = "Reverse List: ";
		Node current = trailer.prev;
		
		while(current != header) {
			r += current + " ";
			current = current.prev;
		}
		return r;
	}
	
	private void addBetween(Node before, Node after, T v) {
		if(before == null || after == null) {
			throw new IllegalArgumentException("Either before or after node is null. ");
		}
		if(before.next != after) {
			throw new IllegalArgumentException("The two nodes are not next to each other.");
		}
		Node newNode = new Node(v);
		newNode.prev = before;
		newNode.next = after;
		
		
		before.next = newNode;
		after.prev = newNode;

		size++;
	}
	
	private T removeBetween(Node node1, Node node2) {
		
		//check if either is null
		if (node1 ==  null || node2 == null) {
			throw new IllegalArgumentException("Must have valid parameters");
		}
		
		//Check for an empty list
		if (header.next ==  trailer) {
			throw new NoSuchElementException("Cannot delete from an empty list");
		}
		
		//check that given nodes are 1 apart
		if(node1.next.next != node2) {
			throw new IllegalArgumentException("Must be 1 node apart");
		}
		
		T valueToReturn = null;
		
		valueToReturn = node1.next.value;
		node1.next = node2;
		node2.prev = node1;
		size--;
		
		return valueToReturn;
	}
	
	public int search(T value){
		int index = 0;
		Node temp = header.next;
		
		do {
			temp = temp.next;
			index++;
			
			if(temp == trailer) {
				return -1;
			}
		}
		while(temp.value!= value);

		return index;
		
	}

	private class Node {
		private Node next;
		private Node prev;
		private T value;
		
		public Node(T v) {
			this.next = null;
			this.prev = null;
			this.value = v;
		}
		
		public String toString() {
			return value.toString();
		}
	}
}