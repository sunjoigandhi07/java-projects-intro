
import java.util.Map.Entry;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;

public class HashMap<K, V> implements Map<K, V>
{
	//List of primes to be used for p value in the MAD compression method
	private final int[] primes = {100663319, 201326611, 402653189,805306457, 1610612741};

	
	//Data members	
	private LinkedList<Entry<K, V>>[] buckets;
	private int numEntries;
	
	
	//hash function = ((hashCode() * a + b) % p) % buckets.length
	private int p;
	private int a;
	private int b;
	
	public HashMap()
	{
		initMap(512);
	}
	
	private void initMap(int bc)
	{
		//Initialize the array
		this.buckets = new LinkedList[ bc ];
		this.numEntries = 0;
		
		//Initialize the linked lists (buckets)
		for(int i=0; i < buckets.length; i++)
		{
			buckets[i] = new LinkedList<>();
		}
		
		//Initialize MAD parameters
		this.p = primes[(int) (Math.random() * primes.length)];
		this.a = (int)(Math.random() * (p-1) + 1);
		this.b = (int)(Math.random() * p);
	}
	
	private int hashFunction(K k)
	{
		// implements the MAD method of compression
		return (Math.abs(k.hashCode() * a + b) % p) % this.buckets.length;
	}
	
	//Map Methods
	@Override
	public V put(K k, V v) 
	{
		expandIfNeeded();
		
		int index = hashFunction(k);
		// If the key is already in the table,
		// overwrite the old value with the new one
		// and return the old value.
		LinkedList<Entry<K, V>> bucket = buckets[index];
		for(Entry<K, V> e : bucket)
		{
			if(e.getKey().equals(k))
			{
				return e.setValue(v);
			}
		}
		
		// If the key doesn't already exist in the map, put the new entry into its bucket.
		bucket.addFirst(new MapEntry(k, v));
		numEntries++;
		return null;
	}

	@Override
	public V get(K k) 
	{
		int index = hashFunction(k);
		for (Entry<K, V> e : buckets[index]){
			if (e.getKey().equals(k)) {
				return e.getValue();
			}
		}
		return null;
		
	}

	@Override
	public V remove(K k) {
		// To be implemented in lab
		return null;
	}

	@Override
	public boolean isEmpty() 
	{
		return this.numEntries == 0;
	}

	@Override
	public int size() {
		return this.numEntries;
	}

	@Override
	public Iterable<K> keySet() 
	{
		ArrayList<K> keys = new ArrayList<K>();
		for (LinkedList<Entry<K, V>> l : buckets) {
			for(Entry<K, V> e : l) {
				keys.add(e.getKey());
			}
		}
		return keys;
	}

	@Override
	public Iterable<V> values() 
	{
		ArrayList<V> values = new ArrayList<>();
		for(LinkedList<Entry<K, V>> bucket : buckets)
		{
			for(Entry<K, V> e : bucket)
			{
				values.add(e.getValue());
			}
		}
		return values;
	}

	@Override
	public Iterable<Entry<K, V>> entrySet() 
	{
		ArrayList<Entry<K, V>> entries = new ArrayList<>();
		for(LinkedList<Entry<K, V>> bucket : buckets)
		{
			for(Entry<K, V> e : bucket)
			{
				entries.add(e);
			}
		}
		return entries;
	}
	
	public String toString()
	{
		String r = "";
		int largestBucket = 0;
		
		for(int i=0; i < buckets.length; i++)
		{
			if(this.buckets[i].size() > largestBucket)
			{
				largestBucket = this.buckets[i].size();
			}
			r += "Bucket " + i + "( " + this.buckets[i].size() + " ) - ";
			for(Entry<K, V> e : this.buckets[i])
			{
				r += e + " ";
			}
			r += "\n";
		}
		r += "\nNumber of Entries: " + this.size() + "\nLargest Bucket: " + largestBucket + "\nLambda = " + (double)this.size()/buckets.length;
		
		return r;

	}
	//if past threshold, double buckets and rehash the entries
	private void expandIfNeeded()
	{
		if (((double)numEntries / buckets.length) > .75) {
			Iterable<Entry<K, V>> entries = entrySet();
			initMap(buckets.length * 2);
			for (Entry <K, V> e : entries) {
				put(e.getKey(), e.getValue());
			}
		}
	}

	private class MapEntry implements Entry<K, V>
	{
		private K key;
		private V value;
		
		public MapEntry(K k, V v)
		{
			this.key = k;
			this.value = v;
		}

		@Override
		public K getKey() {
			return key;
		}

		@Override
		public V getValue() {
			return value;
		}

		@Override
		public V setValue(V val) 
		{
			V oldValue = this.value;
			this.value = val;
			return oldValue;
		}
		
		public String toString()
		{
			return "(" + this.key.toString() + " : " + this.value.toString() + ")";
		}
		
	}
}
