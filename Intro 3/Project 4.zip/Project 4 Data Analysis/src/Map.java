import java.util.Map.Entry;

public interface Map<K, V> 
{
	//Primary operations
	public V get(K key);
	public V put(K key, V value);
	public V remove(K key);
	
	//Iteration methods
	public Iterable<K> keySet();
	public Iterable<V> values();
	public Iterable<Entry<K, V>> entrySet(); 
	

	//size methods
	public int size();
	public boolean isEmpty();
}