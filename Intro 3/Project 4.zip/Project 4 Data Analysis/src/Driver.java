import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Driver {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in); 
		Table testTable = new Table();
		
		
		while(true) {
	
			System.out.println("Would you like a graph (a) or list of popular names (b)?"); 
			String input = scanner.next(); 
			if(input.equals("a")) {
				testTable.graph();
			}
			
			if(input.equals("b")) {
				System.out.println(testTable.mostCommon());
			}
		}
	}
}