import java.util.Scanner;
import edu.du.dudraw.DUDraw;

import java.util.ArrayList;
import java.util.Collections;
import java.io.File;
import java.io.FileNotFoundException;
import java.lang.Comparable;

public class Table {
	private int[] totalFemale = new int[TOTAL_YEARS];
	private int[] totalMale = new int[TOTAL_YEARS];
	public HashMap<String, Name> map = new HashMap<String, Name>();
	private static final int TOTAL_YEARS = 2020 - 1880 + 1;
	private static final int FIRST_YEAR = 1880;
	Scanner scanner = new Scanner(System.in);

	public Table() {

		//try catch to real the baby names file
		try {
			for (int i = 0; i < TOTAL_YEARS; i++) {
				
				File file = new File("babynames/yob"+ (i + 1880) + ".txt");
				
				Scanner s = new Scanner(file);
				while (s.hasNext()) {
					
					String line = s.next();
					String[] text = line.split(",");
					int year = i + 1880;
					int total = Integer.parseInt(text[2]);
					Name n = new Name(year, text[0], text[1].charAt(0), total);
					switch (n.gender) {
					case F:
						totalFemale[i] += total;
						break;
					case M:
						totalMale[i] += total;
					}
					
					map.put(text[0] + year + n.gender.toString(), n);
				}
				s.close();
			}
			for (Name n : map.values()) {
				switch (n.gender) {
				case M:
					n.setFreq(totalMale[n.year - FIRST_YEAR]);
					break;
				case F:
					n.setFreq(totalFemale[n.year - FIRST_YEAR]);
					break;
				}
			}
				
		}catch(FileNotFoundException e)
		{
				e.printStackTrace();

		}

	}

	public void graph() {
		
		System.out.println("Would you like a graph or list of popular names?"); 
		
		
		System.out.println("Enter name:");
		String n = scanner.nextLine();
		System.out.println("Enter M or F");
		
		boolean correct = true;
		char g;
		
		do {
			g = scanner.nextLine().charAt(0);
			switch (g) {
			case 'M':
			case 'm':
				correct = true;
				g = 'M';
				break;
			case 'F':
			case 'f':
				correct = true;
				g = 'F';
				break;
			default:
				
				System.out.println(g + " is not M or F, try again");
				correct = false;
			}
		} while (!correct);	
		
		double max = 0;
		int maxYear = 0;
		int first = 0;

		double[] num = new double[TOTAL_YEARS];
		
		for (int i = 0; i < TOTAL_YEARS; i++) {
			Name name = map.get(n + (i + FIRST_YEAR) + g);
			
			if (name == null) {
				num[i] = 0;

			} else {
				if (first == 0) {
					first = i + FIRST_YEAR;
				}
				double f = name.freqPer;
				num[i] = f;
				
				if (max < f) {
					max = f;
					maxYear = i + FIRST_YEAR;
				}
			}
		}
		
		Name maxName = map.get(n + maxYear + g);
		
		if (maxName == null) {
			System.out.println("Not a name! ");
			
			graph();
			
			return;
		}
		
		//creating DU draw graph 
		DUDraw.enableDoubleBuffering();
		DUDraw.setCanvasSize(400, 400);
		DUDraw.setXscale(0, TOTAL_YEARS);
		DUDraw.setYscale(0, 125);
		DUDraw.setPenColor(DUDraw.BLACK);
		
		for (int i = 0; i < TOTAL_YEARS; i++) {
			double height;
			height = num[i] / max * 0.5 * 100;
			DUDraw.filledRectangle(i + 0.5, height, .5, height);
		}
		
		DUDraw.text(TOTAL_YEARS / 2, 115, maxName.name + ", " + maxName.gender.toString() + ", First use " + first);
		DUDraw.text(TOTAL_YEARS / 2, 107, "Max Frequency: " + maxName.prettyFreq() + " in " + maxYear);
		DUDraw.show();
	}

	public int getTotal(Name n) {
		switch (n.gender) {
		case M:
			return n.freq / totalMale[n.year - FIRST_YEAR];
		case F:
			return n.freq / totalFemale[n.year - FIRST_YEAR];
		default:
			throw new IllegalArgumentException("Gender must be M or F");
		}
	}

	public String mostCommon() {
		System.out.println("What year?");
		int year = scanner.nextInt();
		
		
		System.out.println("How many names?");
		int number = scanner.nextInt();
		
		String toReturn = "";
		ArrayList<Name> list = new ArrayList<Name>();
		
		for (Name n : map.values()) {	
			//Takes O(n) time;  n is the number of names total
			if (n.year == year) {
				list.add(n);
			}
		}
		//Takes O(log n);  n is the number of names that year
		Collections.sort(list);	
		
		for (int i = 0; i < number; i++) {
			toReturn += (i + 1) + "- " + list.get(i).name + ": " + list.get(i).gender.toString() + ", "
					+ list.get(i).freq + "\n";
		}
		//Takes O(n); n is the number of names total
		return toReturn;
		
		//To improve the run time from O(n), we could use an ArrayList of ArrayLists that holds one list per year
					
	}

	//name class
	public class Name implements Comparable<Name> {
		private int year;
		private int freq;
		private String name;
		private double freqPer;

		enum Gender {
			M, F
		};

		Gender gender;

		public Name(int y, String n, char g, int f) {
			name = n;
			
			switch (g) {
			case 'F':
			case 'f':
				gender = Gender.F;
				break;
			case 'M':
			case 'm':
				gender = Gender.M;
				break;
			default:
				throw new IllegalArgumentException("Gender must be M or F");
			}
			
			year = y;
			freq = f;
			freqPer = 0;
		}

		
		public String prettyFreq() {
			return String.format("%.3f", freqPer) + "%";
		}

		//calculate frequency 
		public void setFreq(int total) {
			freqPer = (double) freq / (double) total * 100;
		}
		
		//frequency of name per year to string method
		public String toString() {
			return name + ": year: " + year + " Gender: " + toString(gender) + " freq: " + freq + " freqPer " + prettyFreq();
		}

		//female/male to string method
		public String toString(Gender g) {
			if (g == Gender.F) {
				return "F";
			} else {
				return "M";
			}
		}

		@Override
		public int compareTo(Name o) {
		
			if (this.freq < o.freq) {
				return 1;
			}
			
			if (this.freq > o.freq) {
				return -1;
			} else {
				return 0;
			}

		}
	}

}