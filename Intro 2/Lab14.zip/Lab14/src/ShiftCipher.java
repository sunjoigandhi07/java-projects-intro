// I worked with Nora, Yulia, and Colton 
public class ShiftCipher implements MessageEncoder{
	
	int shift; 
	
	public ShiftCipher(int s) {
		shift = s; 
	}
	
	public String encode(String plaintext) {
		char [] char1 = plaintext.toCharArray(); 
		//loops over all the indexes and finds the ascii number 
		for(int i = 0; i < char1.length; i ++) {
			char1[i] = (char)((char1[i] + shift) % 128); 
		}
		//converts char array to a string 
		String str = new String(char1); 
		return str; 
	}	
}
