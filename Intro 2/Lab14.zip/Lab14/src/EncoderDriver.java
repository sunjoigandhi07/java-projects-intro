
public class EncoderDriver {

	public static void main(String[] args) {
		ShiftCipher shiftTest = new ShiftCipher(3);
		
		System.out.println(shiftTest.encode("Facetiously")); 
		
		ShuffleCipher shuffleTest = new ShuffleCipher(3); 
		
		System.out.println(shuffleTest.encode("Facetiously")); 
		
	}

}
