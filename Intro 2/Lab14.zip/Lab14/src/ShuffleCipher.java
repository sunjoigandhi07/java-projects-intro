// I worked with Yulia, Colton, and Nora 
public class ShuffleCipher implements MessageEncoder {

	int shuffle;

	public ShuffleCipher(int n) {
		shuffle = n;
	}

	public String shuffle(String plaintext) {
		int length = plaintext.length();
		int half = (length / 2);
		// splits odd strings to make the left string larger
		if (length % 2 != 0) {
			half++;
		}

		String stringOne = plaintext.substring(0, half);
		String stringTwo = plaintext.substring(half);

		char[] out = new char[length];
		for (int i = 0; i < stringTwo.length(); i++) {
			out[i * 2] = stringOne.charAt(i);
			out[i * 2 + 1] = stringTwo.charAt(i);

		}
		if (length % 2 != 0) {
			out[length - 1] = stringOne.charAt(stringOne.length() - 1);
		}

		return new String(out);
	}

	public String encode(String plaintext) {
		for (int i = 0; i < shuffle; i++) {
			plaintext = shuffle(plaintext);
		}

		return plaintext;
	}

}
