// I worked with Yulia, Colton, and Nora 
public interface MessageEncoder {
	public String encode(String plaintext);
	
}
