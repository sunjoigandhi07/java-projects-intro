import java.awt.Color;

public class NormalCircle extends MovingCircle {

	public NormalCircle(double radius) {
		super(radius);
		super.setColor(Color.blue);
	}

	public void move() {
		forward();
		bounce();
	}
}
