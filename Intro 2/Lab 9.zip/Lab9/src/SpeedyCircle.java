import java.awt.Color;

public class SpeedyCircle extends NormalCircle {
	public SpeedyCircle(double radius) {
		super(radius);
		super.setColor(Color.green);
	}

	public void bounce() {
		if (xPos + xVel >= 1 || xPos + xVel <= 0) {
			xVel *= -1.05;
		}
		if (yPos + yVel >= 1 || yPos + yVel <= 0) {
			yVel *= -1.05;
		}

	}

}
