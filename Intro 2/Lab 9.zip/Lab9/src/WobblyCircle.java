import java.awt.Color;

public class WobblyCircle extends MovingCircle {
	public WobblyCircle(double radius) {
		super(radius);
		super.setColor(Color.red);
	}

	public void move() {
		forward();
		xPos += Math.random() * 0.02 - 0.01;
		yPos +=  Math.random() * 0.02 - 0.01;
		bounce();
	}

}
