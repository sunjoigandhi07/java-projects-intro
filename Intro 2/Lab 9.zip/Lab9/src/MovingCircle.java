import java.awt.Color;
import edu.du.dudraw.DUDraw;

public abstract class MovingCircle {
	protected double xPos;
	protected double yPos;
	protected double xVel;
	protected double yVel;
	private Color color;
	protected double r;

	// constructor
	public MovingCircle(double radius) {
		xPos = Math.random();
		yPos = Math.random();
		xVel = Math.random() * 0.02 - 0.01;
		yVel = Math.random() * 0.02 - 0.01;
		r = radius;
	}

	public abstract void move();

	public void draw() {
		DUDraw.setPenColor(color);
		DUDraw.filledCircle(xPos, yPos, r);
	}

	public void forward() {
		xPos += xVel;
		yPos += yVel;
	}

	public void bounce() {
		if (xPos + xVel >= 1 || xPos + xVel <= 0) {
			xVel *= -1;
		}
		if (yPos + yVel >= 1 || yPos + yVel <= 0) {
			yVel *= -1;
		}
	}

	public void setColor(Color c) {
		this.color = c;
	}
}
