//I worked with Yulia & Nora
import edu.du.dudraw.DUDraw;

public class Driver {

	public static void main(String[] args) {
		DUDraw.setCanvasSize(600, 600);
		DUDraw.setXscale(0, 1);
		DUDraw.setYscale(0, 1);
		DUDraw.enableDoubleBuffering();

		MovingCircle[] circles = new MovingCircle[6];

		circles[0] = new NormalCircle(0.05);
		circles[1] = new SpeedyCircle(0.04);
		circles[2] = new WobblyCircle(0.03);
		circles[3] = new NormalCircle(0.055);
		circles[4] = new SpeedyCircle(0.045);
		circles[5] = new WobblyCircle(0.035); 

		while (true) {
			DUDraw.clear();

			for (int i = 0; i < circles.length; i++) {
				circles[i].draw();
				circles[i].move();
			}

			DUDraw.show();
			DUDraw.pause(150);
		}
	}
}