import edu.du.dudraw.DUDraw; 

public class Project2Driver {

	public static void main(String[] args) {
		Simulator game = new Simulator(600,600); 
		
		while(true) {
			game.switchMode();
			
			int xMouse = (int)DUDraw.mouseX();
			int yMouse = (int)DUDraw.mouseY();
			
			if(DUDraw.isMousePressed()) {
				game.placeElement(xMouse, yMouse);
			}
			game.update();
			
			DUDraw.clear();
			game.draw(); 
			DUDraw.show();
			DUDraw.pause(15);
		}

	}

}
