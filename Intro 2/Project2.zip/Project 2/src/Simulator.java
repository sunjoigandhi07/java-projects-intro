import edu.du.dudraw.DUDraw;

public class Simulator {
	// enums
	enum Mode {
		SAND, FLOOR
	};

	enum Element {
		SAND, FLOOR, EMPTY
	};

	// instance variables
	private int width;
	private int height;
	private Element contents[][];
	private Mode currentMode;

	// constructor
	public Simulator(int width, int height) {
		this.width = width;
		this.height = height;
		this.contents = new Element[width][height];
		for (int i = 0; i < contents.length; i++) {
			for (int j = 0; j < contents[i].length; j++) {
				contents[i][j] = Element.EMPTY;
			}
		}

		this.currentMode = Mode.SAND;

		// setting canvas & scale size
		DUDraw.setCanvasSize(width, height);
		DUDraw.setXscale(0, width);
		DUDraw.setYscale(0, height);
		DUDraw.enableDoubleBuffering();

	}

	// switches mode based on the key passed in
	public void switchMode() {
		if (DUDraw.hasNextKeyTyped()) {
			char key = DUDraw.nextKeyTyped();
			if (key == 's' || key == 'S') {
				// set mode to sand if S is pressed
				this.currentMode = Mode.SAND;
			}
			if (key == 'f' || key == 'F') {
				// set mode to floor is F is pressed
				this.currentMode = Mode.FLOOR;
			}
		}
	}

	// getter for the current mode
	public Mode getCurrentMode() {
		return this.currentMode;
	}

	public void placeElement(int row, int col) {
		int size = 2;
		for (int i = -size; i <= size; i++) {
			for (int j = -size; j < size; j++) {
				if (row + 1 < 0 || row + i >= height) {
					continue;
				}
				if (col + j < 0 || col + j >= width) {
					continue;
				}
				if (currentMode == Mode.SAND && Math.random() < 0.03) {
					this.contents[row + i][col + j] = Element.SAND;
				}
				if (currentMode == Mode.FLOOR) {
					this.contents[row + i][col + j] = Element.FLOOR;
				}
			}
		}
	}

	public void update() {
		for (int i = 0; i < contents.length; i++) {
			for (int j = 0; j < contents[i].length; j++) {
				if (j - 1 > -1 && contents[i][j] == Element.SAND && contents[i][j - 1] == Element.EMPTY) {
					// checks if the cell is empty
					contents[i][j] = Element.EMPTY;
					// checks if the cell below is empty
					contents[i][j - 1] = Element.SAND;
				}
			}
		}
	}

	public void draw() {
		for (int i = 0; i < contents.length; i++) {
			for (int j = 0; j < contents[i].length; j++) {
				if (contents[i][j] == Element.SAND) {
					// sets color to sand color
					DUDraw.setPenColor(200, 190, 140);
					// draws the sand grains
					DUDraw.point(i, j);
				}
				if (contents[i][j] == Element.FLOOR) {
					DUDraw.setPenColor(DUDraw.BLACK);
					DUDraw.point(i, j);
				}
			}
		}
		DUDraw.setPenColor(DUDraw.BLACK);
		if (currentMode == Mode.SAND) {
			// displays sand mode on the canvas
			DUDraw.text(width / 2, height - 32, "SAND MODE");
		}
		if (currentMode == Mode.FLOOR) {
			// displays floor mode on the canvas
			DUDraw.text(width / 2, height - 32, "FLOOR MODE");
		}
	}
}
