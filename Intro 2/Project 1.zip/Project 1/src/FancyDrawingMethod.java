import edu.du.dudraw.DUDraw;
import java.awt.Color; 

public class FancyDrawingMethod {

	private static int starCounter = 0; 
	private static int nGonCounter = 0; 
	private static int starNCounter = 0; 
	
	public static void starWithFourPoints(double centerX, double centerY, double radius) {
		double[] arrayX = { (centerX), (centerX + (radius / 3)), (centerX + (radius)), (centerX + (radius / 3)),
				(centerX), (centerX - (radius / 3)), (centerX - (radius)), (centerX - (radius / 3)) };
		double[] arrayY = { (centerY + (radius)), (centerY + (radius / 3)), centerY, (centerY - (radius / 3)),
				(centerY - (radius)), (centerY - radius / 3), (centerY), (centerY + (radius / 3)) };

		DUDraw.filledPolygon(arrayX, arrayY);
		starCounter ++; 
	}
	//getter for starWithFourPoints 
	public static int getStarCounter() {
		return starCounter; 
	}

	public static void filledRegularNgon(double centerX, double centerY, double radius, int n) { 
		double[] xCoord = new double[n];
		double[] yCoord = new double[n];

		for (int i = 0; i < n; i++) {
			double theta = ((2 * Math.PI) / n);

			xCoord[i] = centerX + radius * Math.cos(theta * i);
			yCoord[i] = centerY + radius * Math.sin(theta * i);
		}
		DUDraw.filledPolygon(xCoord, yCoord);
		nGonCounter ++; 
	}
	// getter for filledRegularNGon
	public static int getNGonCounter() {
		return nGonCounter; 
	}

	public static void starWithNPoints(double centerX, double centerY, double radius, int numPoints) {
		double[] x = new double[numPoints * 2];
		double[] y = new double[numPoints * 2];

		for (int i = 0; i < numPoints * 2; i++) {
			double angle = ((2 * Math.PI) / (numPoints * 2));
			double r = radius / 2;
			if (i % 2 != 0) {
				x[i] = centerX + r * Math.cos(angle * i);
				y[i] = centerY + r * Math.sin(angle * i);
			} else {
				x[i] = centerX + radius * Math.cos(angle * i);
				y[i] = centerY + radius * Math.sin(angle * i);
			}
		}
		DUDraw.filledPolygon(x, y);
		starNCounter ++; 
	}
	
	public static int getStarNCounter() {
		return starNCounter; 
	}
	
	//3 static color constants 
	public static final Color LAVENDER = new Color(220, 150, 250); 
	public static final Color APPLE = new Color (255, 70, 0); 
	public static final Color MUSTARD = new Color(170, 150, 50); 
}
