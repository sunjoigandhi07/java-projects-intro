import edu.du.dudraw.DUDraw;

public class Driver {

	public static void main(String[] args) {
		// DU Draw face set up
		DUDraw.setCanvasSize(600, 600);
		DUDraw.setPenRadius(3);
		DUDraw.setPenColor(DUDraw.MAGENTA);
		DUDraw.filledCircle(0.5, 0.5, 0.4);
		
		// eyes
		DUDraw.setPenColor(FancyDrawingMethod.LAVENDER);
		FancyDrawingMethod.starWithFourPoints(0.3, 0.6, 0.07);
		DUDraw.setPenColor(FancyDrawingMethod.MUSTARD); 
		FancyDrawingMethod.starWithFourPoints(0.7, 0.6, 0.07);

		// nose
		DUDraw.setPenColor(FancyDrawingMethod.MUSTARD);
		FancyDrawingMethod.filledRegularNgon(0.45, 0.45, 0.03, 10);
		DUDraw.setPenColor(FancyDrawingMethod.LAVENDER); 
		FancyDrawingMethod.filledRegularNgon(0.55, 0.45, 0.03, 10);

		//mouth 
		DUDraw.setPenColor(FancyDrawingMethod.APPLE); 
		FancyDrawingMethod.starWithNPoints(0.35, 0.3, 0.03, 15);
		FancyDrawingMethod.starWithNPoints(0.65, 0.3, 0.03, 15);
		DUDraw.line(0.35, 0.3, 0.65, 0.3);
		
		//output to consol 
		System.out.println("Number of calls to starWithFourPoints: " + FancyDrawingMethod.getStarCounter());
		System.out.println("Number of calls to regularNgon: " + FancyDrawingMethod.getNGonCounter());
		System.out.println("Number of calls to starWithNPoints: " + FancyDrawingMethod.getStarNCounter()); 
	}

}