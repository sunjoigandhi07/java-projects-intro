import edu.du.dudraw.DUDraw;
import java.time.LocalTime;

public class clockDriver {
// Worked with Saroja M. on this assignment
	public static void main(String[] args) {
		DUDraw.enableDoubleBuffering();
		DUDraw.setCanvasSize(600,600);
		
		while(true) {
			DUDraw.clear();
			// clock circles (lol yes, I made 12 individual circles)
			DUDraw.setPenColor(DUDraw.BLACK);
			DUDraw.filledCircle(0.5, 0.9, 0.02);
			DUDraw.filledCircle(0.5, 0.1, 0.02);
			DUDraw.filledCircle(0.9, 0.5, 0.02);
			DUDraw.filledCircle(0.1, 0.5, 0.02);
			DUDraw.filledCircle(0.68, 0.82, 0.02);
			DUDraw.filledCircle(0.82, 0.68, 0.02);
			DUDraw.filledCircle(0.68, 0.2, 0.02);
			DUDraw.filledCircle(0.82, 0.3, 0.02);
			DUDraw.filledCircle(0.2,0.68, 0.02);
			DUDraw.filledCircle(0.35, 0.82, 0.02);
			DUDraw.filledCircle(0.35, 0.2, 0.02);
			DUDraw.filledCircle(0.2,0.3, 0.02);
			
			//get time 
			LocalTime now = LocalTime.now();
			double s = now.getSecond();
			double m = now.getMinute();
			double h = now.getHour();
			
			// angle for x & y coordinates
			double secondsTheta = (s/60) * (2 * Math.PI);
			double minutesTheta = (m/60) * (2 * Math.PI);
			double hoursTheta = (h/12) * (2 * Math.PI);
			
			// x & y coordinates for clock hands @ correct time 
			double secondsX = (0.35 * Math.sin(secondsTheta)) + 0.5;
			double secondsY = (0.35 * Math.cos(secondsTheta)) + 0.5;
			double hourX = (0.2 * Math.sin(hoursTheta)) + 0.5;
			double hourY = (0.2 * Math.cos(hoursTheta)) + 0.5;
			double minuteX = (0.3 * Math.sin(minutesTheta)) + 0.5;
			double minuteY = (0.3 * Math.cos(minutesTheta)) + 0.5;
			
			// seconds hand
			DUDraw.setPenColor(DUDraw.RED);
			DUDraw.setPenRadius(1);
			DUDraw.line(0.5,  0.5, secondsX, secondsY);
			// hour hand 
			DUDraw.setPenRadius(2);
			DUDraw.line(0.5, 0.5, hourX, hourY);
			//minute hand
			DUDraw.line(0.5, 0.5, minuteX, minuteY);
			
			DUDraw.show();
			DUDraw.pause(10);
			
		}
	}
}
