//I worked with Nora, Yulia, Colton, and Saroja

public class Driver {

	public static void main(String[] args) {
		//Testing Queue Class 
		Queue test = new Queue(); 
		
		test.enqueue("First");
		test.enqueue("Second");
		
		System.out.println(test.dequeue()); 
		System.out.println(test.isEmpty()); 
		
		//Testing Stack Class 
		Stack testTwo = new Stack(); 
		
		testTwo.push("Third"); 
		testTwo.push("Forth"); 
		testTwo.push("Fifth"); 
		testTwo.push("Last");
		
		System.out.println(testTwo.pop());
		System.out.println(testTwo.pop());
		System.out.println(testTwo.isEmpty()); 
		
		//Testing PriorityQueue Class 
		PriorityQueue pTest = new PriorityQueue(); 
		pTest.enqueue(12);
		pTest.enqueue(14);
		pTest.enqueue(16);
		
		System.out.println(pTest.dequeue()); 
	}

}
