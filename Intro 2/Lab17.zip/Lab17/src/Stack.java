//I worked with Yulia, Nora, Colton, and Saroja 

import java.util.ArrayList; 

public class Stack <T>{
	ArrayList<T> stack; 
	//Constructor 
	public Stack() {
		stack = new ArrayList<T>(); 
	}
	
	public void push(T el) {
		stack.add(0, el); 
	}
	
	public T pop() {
		if(stack.size() == 0) {
			System.out.println("Queue is empty."); 
			return null;
		}
		T temp = stack.get(0); 
		stack.remove(0); 
		return temp; 
	}	
	
	public boolean isEmpty() {
		if(stack.size() != 0) {
			return false; 
		}
		else {
			return true; 
		}
	}
	
}