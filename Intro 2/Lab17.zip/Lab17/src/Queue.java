//I worked with Saroja, Yulia, Colton, and Nora 

import java.util.ArrayList; 

public class Queue<T>{
	protected ArrayList<T> queue;
	//Constructor 
	public Queue() {
		this.queue = new ArrayList<T>(); 
	}
	
	public void enqueue(T el) {
		queue.add(el); 
	}
	
	public T dequeue() {
		if(queue.size() == 0) {
			System.out.println("Queue is empty."); 
			return null; 
		}
		T temp = queue.get(0); 
		queue.remove(0); 
		return temp;  
	}
	
	public boolean isEmpty() {
		if(queue.size() != 0) {
			return false; 
		}
		else {
			return true; 
		}
	}
} 
