//I worked with Colton, Yulia, Saroja, and Nora 

public class PriorityQueue <T extends Comparable <T>> extends Queue<T>{
	public PriorityQueue() {
		super(); 
	}
	
	public T dequeue() {
		if(queue.size() == 0) {
			System.out.println("Queue is empty."); 
			return null; 
		}
		
		int index = 0; 
		T max = queue.get(0); 
		
		for(int i = 0; i < queue.size(); i ++) {
			int compare = max.compareTo(queue.get(i)); 
			if(compare < 0 || compare == 0) {
				max = queue.get(i); 
				index = 1; 
			}
		}
		queue.remove(index); 
		return max; 
	}
	
}
