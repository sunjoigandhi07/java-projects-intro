// Worked with Nora, Saroja, & Yulia 
import edu.du.dudraw.DUDraw; 

public class TicTacToeDriver {
	public static void main(String[] args) {
		TicTacToe newGame = new TicTacToe();
		
		newGame.playGame();
		
	}
}
