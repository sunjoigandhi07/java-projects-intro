import edu.du.dudraw.DUDraw;

public class TicTacToe {
	// Declare enum of ownership
	enum Contents {
		EMPTY, EX, OH
	};

	// Cell class
	private class Cell {
		private Contents ownership;

		// Cell Constructor
		private Cell() {
			ownership = Contents.EMPTY;
		}
	}

	// Array of Cells for the Tic Tac Toe Board
	private Cell[][] board;

	// Message that changes based on turn and game end condition
	private String message;

	// Boolean to determine turns
	private boolean Xturn;

	public TicTacToe() {
		DUDraw.setCanvasSize(600, 700);
		DUDraw.setXscale(0, 3);
		DUDraw.setYscale(0, 3.5);

		board = new Cell[3][3];

		for (int i = 0; i < board.length; i++) {
			for (int j = 0; j < board[i].length; j++) {
				board[i][j] = new Cell();
			}
		}

		this.message = "It's X's turn";
		this.Xturn = true;
	}

	public void draw() {
		DUDraw.clear(DUDraw.WHITE);
		DUDraw.setPenColor(DUDraw.BLACK);
		DUDraw.line(1, 0, 1, 3);
		DUDraw.line(2, 0, 2, 3);
		DUDraw.line(0, 1, 3, 1);
		DUDraw.line(0, 2, 3, 2);
		DUDraw.text(1.5, 3.25, this.message);

		for (int i = 0; i < board.length; i++) {
			for (int j = 0; j < board[i].length; j++) {
				if (board[i][j].ownership == Contents.EX) {
					DUDraw.text(j + 0.5, i + 0.5, "X");
				} else if (board[i][j].ownership == Contents.OH) {
					DUDraw.circle(j + 0.5, i + 0.5, 0.03);
				}
			}
		}
	}

	public void playGame() {
		DUDraw.enableDoubleBuffering();
		do {
			draw();

			if (DUDraw.isMousePressed()) {
				if (board[(int) DUDraw.mouseY()][(int) DUDraw.mouseX()].ownership == Contents.EMPTY) {
					if (Xturn == true) {
						board[(int) DUDraw.mouseY()][(int) DUDraw.mouseX()].ownership = Contents.EX;
						Xturn = !Xturn;
						this.message = "It's O's Turn";
					} else if (Xturn == false) {
						board[(int) DUDraw.mouseY()][(int) DUDraw.mouseX()].ownership = Contents.OH;
						Xturn = !Xturn;
						this.message = "It's X's Turn"; 
					}
				}
			}

			DUDraw.show();
			DUDraw.pause(100);

			// Check game end conditions
		} while (!gameWon() && !allFilled());
		if (gameWon()) {
			message = Xturn ? "Game over, O wins!" : "Game over, X wins!";
		} else {
			message = "Game over, it's a tie!";
		}
		draw();
		DUDraw.show();
	}

	// Check if someone has won the game
	public boolean gameWon() {
		// Returns true if a row, column or diagonal contains all O's or X's
		// Note: you may want to make use of the wins() method below.

		// TODO: check each row
		if (board[0][0].ownership == Contents.EX && board[0][1].ownership == Contents.EX
				&& board[0][2].ownership == Contents.EX) {
			return true;
		}
		if (board[1][0].ownership == Contents.EX && board[1][1].ownership == Contents.EX
				&& board[1][2].ownership == Contents.EX) {
			return true;
		}
		if (board[2][0].ownership == Contents.EX && board[2][1].ownership == Contents.EX
				&& board[2][2].ownership == Contents.EX) {
			return true;
		}
		if (board[0][0].ownership == Contents.OH && board[0][1].ownership == Contents.OH
				&& board[0][2].ownership == Contents.OH) {
			return true;
		}
		if (board[1][0].ownership == Contents.OH && board[1][1].ownership == Contents.OH
				&& board[1][2].ownership == Contents.OH) {
			return true;
		}
		if (board[2][0].ownership == Contents.OH && board[2][1].ownership == Contents.OH
				&& board[2][2].ownership == Contents.OH) {
			return true;
		}

		// TODO: check each column
		if (board[0][0].ownership == Contents.EX && board[1][0].ownership == Contents.EX
				&& board[2][0].ownership == Contents.EX) {
			return true;
		}
		if (board[0][1].ownership == Contents.EX && board[1][1].ownership == Contents.EX
				&& board[2][1].ownership == Contents.EX) {
			return true;
		}
		if (board[0][2].ownership == Contents.EX && board[1][2].ownership == Contents.EX
				&& board[2][2].ownership == Contents.EX) {
			return true;
		}
		if (board[0][0].ownership == Contents.OH && board[1][0].ownership == Contents.OH
				&& board[2][0].ownership == Contents.OH) {
			return true;
		}
		if (board[0][1].ownership == Contents.OH && board[1][1].ownership == Contents.OH
				&& board[2][1].ownership == Contents.OH) {
			return true;
		}
		if (board[0][2].ownership == Contents.OH && board[1][2].ownership == Contents.OH
				&& board[2][2].ownership == Contents.OH) {
			return true;
		}

		// TODO: check diagonals
		if (board[0][0].ownership == Contents.EX && board[1][1].ownership == Contents.EX
				&& board[2][2].ownership == Contents.EX) {
			return true;
		}
		if (board[2][0].ownership == Contents.EX && board[1][1].ownership == Contents.EX
				&& board[0][2].ownership == Contents.EX) {
			return true;
		}
		if (board[0][0].ownership == Contents.OH && board[1][1].ownership == Contents.OH
				&& board[2][2].ownership == Contents.OH) {
			return true;
		}
		if (board[2][0].ownership == Contents.OH && board[1][1].ownership == Contents.OH
				&& board[0][2].ownership == Contents.OH) {
			return true;
		}

		return false;

	}

	// Check if three squares are the same (and not empty)
	private boolean wins(Contents c1, Contents c2, Contents c3) {
		if (c1 == Contents.EMPTY)
			return false;
		return c1 == c2 && c1 == c3;
	}

	private boolean allFilled() {

		// TODO: Method returns true if all cells are filled
		for (int i = 0; i < board.length; i++) {
			for (int j = 0; j < board[i].length; j++) {
				if (board[i][j].ownership == Contents.EMPTY) {
					return false;
				}
			}
		}
		return true;
	}

}