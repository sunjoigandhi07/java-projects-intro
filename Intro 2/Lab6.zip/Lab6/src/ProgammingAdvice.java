//I worked with Saroja 

import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;

public class ProgammingAdvice {
	public static void main(String[] args) {
		Scanner kb = new Scanner(System.in);
		Scanner fileReader = new Scanner(System.in);
		Scanner input = null;
		PrintWriter output = null;

		try {
			File inFile = new File("advice.txt");
			input = new Scanner(inFile);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}

		if (input != null) {
			System.out.println("My advice is: ");
			String lineOne = input.nextLine();
			System.out.println(lineOne);
			input.close();
		}

		try {
			output = new PrintWriter(new File("advice.txt"));
		} catch (FileNotFoundException f) {
			f.printStackTrace();
		}

		if (output != null) {
			System.out.println("Enter your advice: ");
			String newAdvice = kb.nextLine();
			output.println(newAdvice);
			output.close();
		}
	}

}
