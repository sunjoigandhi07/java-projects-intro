import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;

public class NumberReader {

	public static void main(String[] args) {
		File inFile = new File("RandomInts1.dat");
		inFile.exists();
		inFile.length();

		try {
			RandomAccessFile raf = new RandomAccessFile(inFile, "rw");
			int fileLength = raf.readInt();
			int biggestNum = 0;
			int smallestNum = 0;

			for (int i = 0; i < fileLength; i++) {
				int x = raf.readInt();

				if (i == 0) {
					biggestNum = x;
					smallestNum = x;
				}

				if (x > biggestNum) {
					biggestNum = x;
				}
				if (x < smallestNum) {
					smallestNum = x;
				}

			}

			System.out.println("Max: " + biggestNum);
			System.out.println("Min: " + smallestNum);
			System.out.println("Number of integers: " + inFile.length());
			raf.close();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

}
