import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import edu.du.dudraw.DUDraw;

public class Driver {

	public static void main(String[] args) throws FileNotFoundException {
		File inFile = new File("Emoji.txt");
		Scanner input = new Scanner(inFile);

		int height = input.nextInt();
		int width = input.nextInt();
		
		DUDraw.setCanvasSize(width * 100, height * 100);
		DUDraw.setXscale(0, width * 100);
		DUDraw.setYscale(0, height * 100);

		Emoji[][] faces = new Emoji[height][width];

		for (int i = 0; i < faces.length; i++) {
			for (int j = 0; j < faces[i].length; j++) {
				String emojiType = input.next();

				// check to draw a smiley face
				if (emojiType.equals("smile")) {
					faces[i][j] = new SmileyFaceEmoji(j * 100 + (50), i * 100 + (50), 50);
				}
				
				// check to draw surprised face
				if (emojiType.equals("surprise")) {
					faces[i][j] = new SuprisedFaceEmoji(j * 100 + (50), i * 100 + (50), 50);
				}
				
				// check to draw a clock
				if (emojiType.equals("clock")) {
					int hour = input.nextInt();
					faces[i][j] = new ClockEmoji(j * 100 + (50), i * 100 + (50), 50, hour);
				}
			}
		}

		for (int i = 0; i < faces.length; i++) {
			for (int j = 0; j < faces[i].length; j++) {
				faces[i][j].draw();
			}
		}
	}
}
