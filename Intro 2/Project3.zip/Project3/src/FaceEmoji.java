import edu.du.dudraw.DUDraw;

public abstract class FaceEmoji extends Emoji {
	public FaceEmoji(double x, double y, double size) {
		super(x, y, size);
	}

	public void draw() {
		//yellow circle as head 
		DUDraw.setPenColor(DUDraw.YELLOW);
		DUDraw.filledCircle(xCoord, yCoord, size);

		//black eyeballs 
		DUDraw.setPenColor(DUDraw.BLACK);
		DUDraw.filledCircle(xCoord - (size / 2), yCoord + (size / 2), size / 8);
		DUDraw.filledCircle(xCoord + (size / 2), yCoord + (size / 2), size / 8);
	}
}
