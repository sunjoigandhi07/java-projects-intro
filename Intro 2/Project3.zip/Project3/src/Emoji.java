
public abstract class Emoji {
	double xCoord;
	double yCoord;
	double size;

	public Emoji(double x, double y, double size) {
		this.xCoord = x;
		this.yCoord = y;
		this.size = size;
	}

	public abstract void draw();
}