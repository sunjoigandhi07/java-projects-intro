import edu.du.dudraw.DUDraw;

public class SuprisedFaceEmoji extends FaceEmoji {

	public SuprisedFaceEmoji(double x, double y, double size) {
		super(x, y, size);
	}

	public void draw() {
		super.draw();
		//surprised mouth 
		DUDraw.filledCircle(xCoord, yCoord - (size / 3), size / 5);
	}
}
