import edu.du.dudraw.DUDraw;

public class ClockEmoji extends Emoji {

	int hour;

	public ClockEmoji(double x, double y, double size, int h) {
		super(x, y, size);
		hour = h;
	}

	public void draw() {
		DUDraw.circle(xCoord, yCoord, size);

		double hoursTheta = (((double) hour / 12) * (2 * Math.PI));
		double hoursX = size * (Math.sin(hoursTheta)) + xCoord;
		double hoursY = size * (Math.cos(hoursTheta)) + yCoord;

		DUDraw.line(xCoord, yCoord, hoursX, hoursY);
	}
}