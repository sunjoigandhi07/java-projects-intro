
public class HotDogClass {
	//instance variables
	private String standName;
	private int standId;
	private int dogsSold; 
	 
	//static variables 
	private static int uniqueId = 0;
	private static int totalDogsSold;
	//constructor
	public HotDogClass(String name) {
		this.standName = name; 
			standId= uniqueId;
			uniqueId ++;
			dogsSold = 0;
			
	}
	//method for 1 dog sold
	 public void justSold() {
		 dogsSold += 1;
		 totalDogsSold += 1;
	 }
	 //method for several dogs sold
	 public void justSold(int numSold) {
		 dogsSold += numSold;
		 totalDogsSold += numSold; 
	 }
	 //getters
	 public String getStandName() {
		 return standName;
	 }
	 
	 public int getStandId() {
		return standId; 
	 }
	 
	 public int getDogsSold() {
		 return dogsSold;
	 }
	 
	 public static int getNumTotal() {
		 return totalDogsSold;
	 }
}
