//worked with Saroja M. on this lab
public class HotDogClassDriver {

	public static void main(String[] args) {
		HotDogClass stand1 = new HotDogClass("Wack Weiners");
		HotDogClass stand2 = new HotDogClass("Wacky Weiners");
		HotDogClass stand3 = new HotDogClass("Wacko Weiners");
		
		for(int i = 0; i < 5; i++) {
			stand1.justSold();
			stand1.justSold(2);
			
			stand2.justSold();
			stand2.justSold(4);
			
			stand3.justSold();
			stand3.justSold(6);
			
		}
		
		System.out.println(stand1.getStandName());
		System.out.println(stand1.getStandId());
		System.out.println(stand1.getDogsSold());
		
		System.out.println(stand2.getStandName());
		System.out.println(stand2.getStandId());
		System.out.println(stand2.getDogsSold());
		
		System.out.println(stand3.getStandName());
		System.out.println(stand3.getStandId());
		System.out.println(stand3.getDogsSold());
		
		System.out.println("Total sold = " + HotDogClass.getNumTotal());
	}

}
