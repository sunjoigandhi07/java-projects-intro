//I worked with Yulia, Nora, Saroja, and Colton

import java.util.ArrayList;

public class Gallery {
	ArrayList<Art> gallery;

	// constructor that makes an empty ArrayList
	public Gallery() {
		gallery = new ArrayList<Art>();
	}

	// adds an art object to the gallery ArrayList
	public void addPiece(Art a) {
		gallery.add(a);
	}

	// Prints name and artist for pieces in the gallery
	public void printCollection() {
		for (int i = 0; i < gallery.size(); i++) {
			System.out.println(gallery.get(i).getArtist());
			System.out.println(gallery.get(i).getArtName());
		}
	}
	//returns number of art pieces by a certain artist 
	public int numbersBy(String name) {
		int artistPieces = 0;

		for (Art pieces : gallery) {
			if (pieces.getArtist().equals(name)) {
				artistPieces++;
			}
		}
		return artistPieces;
	}

	// returns number of pieces that have that tag
	public int numberMatching(String tag) {
		int count = 0;

		for (Art pieces : gallery) {
			if (pieces.matches(tag)) {
				count++;
			}
		}
		return count;
	}
}
