//I worked with Yulia, Nora, Saroja, and Colton

public class Driver {

	public static void main(String[] args) {
		Art artOne = new Art("Moe", "Shriya"); 
		Art artTwo = new Art("Martha", "Shriya"); 
		Art artThree = new Art ("Rascal", "Shriya"); 
		
		//Checks the Art Class 
		System.out.println(artOne.getArtist()); 
		System.out.println(artOne.getArtName()); 
		
		artOne.addTag("2017's World Second Ugliest Dog"); 
		
		System.out.println(artOne.matches("2017's World Second Ugliest Dog")); 
		
		//Checks the Gallery Class 
		Gallery galOne = new Gallery(); 
		galOne.addPiece(artOne);
		galOne.addPiece(artTwo); 
		galOne.addPiece(artThree); 
		
		galOne.printCollection(); 
		
		System.out.println(galOne.numbersBy("Shriya")); 
		System.out.println(galOne.numberMatching("2017's World Second Ugliest Dog")); 
	}

}
