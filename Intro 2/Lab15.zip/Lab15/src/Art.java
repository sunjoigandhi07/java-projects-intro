//I worked with Yulia, Nora, Saroja, and Colton 

import java.util.ArrayList;

public class Art {
	private String artist;
	private String artName;
	ArrayList<String> tags;

	public Art(String n, String a) {
		this.artName = n;
		this.artist = a;
		tags = new ArrayList<String>();
	}

	// getter for the artist
	public String getArtist() {
		return artist;
	}

	// getter for the artName
	public String getArtName() {
		return artName;
	}

	// adds string to the arrayList
	public void addTag(String tag) {
		tags.add(tag);
	}

	// checks if that tag in in the arrayList
	public boolean matches(String tag) {
		if (tags.contains(tag)) {
			return true;
		} else {
			return false;
		}
	}
}
