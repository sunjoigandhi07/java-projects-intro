
public class Lab03Driver {

	public static void main(String[] args) {
		PizzaOrder order1 = new PizzaOrder();
		
		Pizza one = new Pizza(PizzaSize.LARGE, 1, 0, 1);
		Pizza two = new Pizza(PizzaSize.MEDIUM, 2, 2, 0);
		
		order1.addPizza(one);
		order1.addPizza(two);

		order1.printOrder();
		
		PizzaOrder order2 = new PizzaOrder();
		
		Pizza three = new Pizza(PizzaSize.SMALL, 2, 0, 0);
		Pizza four = new Pizza(PizzaSize.MEDIUM, 1, 0, 0);
		Pizza five = new Pizza(PizzaSize.LARGE, 3, 0, 0); 
		
		order2.addPizza(three);
		order2.addPizza(four);
		order2.addPizza(five); 
		
		order2.printOrder();
		
		PizzaOrder order3 = new PizzaOrder();
		order3 = order2;
		order3.printOrder();
		
		order1.changePizzaToppings(1, 2, 0, 0);
		order1.printOrder();
		
		order2.changePizzaToppings(1, 0, 0, 1);
		
		order2.printOrder();
		order3.printOrder();
		
	}

}
