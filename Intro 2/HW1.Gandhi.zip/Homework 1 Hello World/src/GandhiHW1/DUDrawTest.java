package GandhiHW1;

import edu.du.dudraw.DUDraw;

public class DUDrawTest {
	public static void main(String[]args) {
		DUDraw.setCanvasSize(600,600);
		DUDraw.clear(Std.Draw.LIGHT_GRAY);
		
		DUDraw.setPenColor(100, 0, 100);
		DUDraw.filledCircle(0.3, 0.3, 0.1);
		
		//this file does not work because the DUDraw file would not load
		//I am using a DUDraw file from a previous course 
	}
}
