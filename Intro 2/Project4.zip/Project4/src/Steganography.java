import java.awt.Color;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.io.RandomAccessFile; 

public class Steganography {

	public Color[][] extractSecretImage(String fileName) {

		try {
			Color[][] image = BMPIO.readBMPFile(fileName);
			for (int i = 0; i < image.length; i++) {
				for (int j = 0; j < image[i].length; j++) {
					int red = (image[i][j].getRed() % 16) * 16;
					int blue = (image[i][j].getBlue() % 16) * 16;
					int green = (image[i][j].getGreen() % 16) * 16;

					image[i][j] = new Color(red, green, blue);

				}
			}
			return image;
		} catch (IOException e) {
			e.printStackTrace();
		}

		return null;
	}

	public Color[][] embedSecretImage(String publicIm, String secretIm) {
	
		try {
			
			String embedPublicIm = "embedded_" + publicIm; 
			Files.copy(Paths.get(publicIm), Paths.get(embedPublicIm), StandardCopyOption.REPLACE_EXISTING); 
			
			RandomAccessFile raf = new RandomAccessFile(embedPublicIm, "rw"); 
			raf.seek(54);
			Color[][] image1 = BMPIO.readBMPFile(publicIm);
			Color[][] image2 = BMPIO.readBMPFile(secretIm);

			for (int i = 0; i < image1.length; i++) {
				for (int j = 0; j < image1[i].length; j++) {

					if (i < image2.length && j < image2[i].length) {

						int hidRed = (image1[i][j].getRed() - (image1[i][j].getRed() % 16))
								+ (image2[i][j].getRed() / 16);
						int hidBlue = (image1[i][j].getBlue() - (image1[i][j].getBlue() % 16))
								+ (image2[i][j].getBlue() / 16);
						int hidGreen = (image1[i][j].getGreen() - (image1[i][j].getGreen() % 16))
								+ (image2[i][j].getGreen() / 16);

						image1[i][j] = new Color(hidRed, hidGreen, hidBlue);

					} else {
						int hidRed = (image1[i][j].getRed() - (image1[i][j].getRed() % 16));
						int hidBlue = (image1[i][j].getBlue() - (image1[i][j].getBlue() % 16));
						int hidGreen = (image1[i][j].getGreen() - (image1[i][j].getGreen() % 16));

						image1[i][j] = new Color(hidRed, hidGreen, hidBlue);
					}
					raf.write(image1[i][j].getBlue());  
					raf.write(image1[i][j].getGreen()); 
					raf.write(image1[i][j].getRed()); 	
				}
			}
			raf.close(); 
			return image1;
		} catch (IOException e) {
			e.printStackTrace();
		}

		return null;
	}
}