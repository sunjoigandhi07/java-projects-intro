import java.util.Scanner; 
import edu.du.dudraw.DUDraw; 
import java.awt.Color;
import java.io.IOException; 

public class Driver  {

	public static void main(String[] args) throws IOException {
		Scanner kb = new Scanner(System.in); 
		
		System.out.println("Hello, would you like to extract an image or embed an image today?"); 
		String userInput = kb.nextLine(); 
		//extract image 
		if(userInput.equals("extract")) {
			System.out.println("Please provide the name of the file (include .bmp)");
			userInput = kb.nextLine(); 
			Steganography extraction = new Steganography(); 
			Color[][] extractIm = extraction.extractSecretImage(userInput); 
			Color[][] originalIm = BMPIO.readBMPFile(userInput); 
			
			
			DUDraw.setCanvasSize(extractIm[0].length *2, extractIm.length); 
			DUDraw.setXscale(0, extractIm[0].length * 2); 
			DUDraw.setYscale(0, extractIm.length);
			
			DUDraw.enableDoubleBuffering();
			
			for(int i = 0; i < extractIm.length; i++) {
				for(int j = 0; j < extractIm[i].length; j++) {
					 DUDraw.setPenColor(extractIm[i][j]); 
					 DUDraw.filledRectangle(j + extractIm[0].length, i, 0.5, 0.5);
					 
					 DUDraw.setPenColor(originalIm[i][j]); 
					 DUDraw.filledRectangle(j, i, 0.5, 0.5);
				}
			}
			DUDraw.show();
		}
		//embed image 
		if(userInput.equals("embed")) {
			System.out.println("Please provide the name of the first file (include .bmp)");
			userInput = kb.nextLine(); 
			System.out.println("Please provide the name of the second file (include .bmp)"); 
			String secondImage = kb.nextLine();
			Steganography embedded = new Steganography(); 
			Color[][] embedIm = embedded.embedSecretImage(userInput, secondImage); 
			Color[][] originalIm = BMPIO.readBMPFile(userInput); 
			
			DUDraw.setCanvasSize(embedIm[0].length *2, embedIm.length); 
			DUDraw.setXscale(0, embedIm[0].length * 2); 
			DUDraw.setYscale(0, embedIm.length);
			
			DUDraw.enableDoubleBuffering();
			
			for(int i = 0; i < embedIm.length; i++) {
				for(int j = 0; j < embedIm[i].length; j++) {
					 DUDraw.setPenColor(embedIm[i][j]); 
					 DUDraw.filledRectangle(j + embedIm[0].length, i, 0.5, 0.5);
					 
					 DUDraw.setPenColor(originalIm[i][j]); 
					 DUDraw.filledRectangle(j, i, 0.5, 0.5);
				}
			}
			DUDraw.show();
		}
	}
}
