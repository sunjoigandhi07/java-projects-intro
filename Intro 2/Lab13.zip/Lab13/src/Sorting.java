//I worked with Nora, Yulia, Saroja, Colton 

public class Sorting {

	public static int selectionSort(int[] array) {
		int unsortedness = 0;

		for (int i = 0; i < array.length - 1; i++) {
			int slot = i;

			for (int j = i + 1; j < array.length; j++) {
				if (array[j] < array[slot]) {
					// looks for lowest index
					slot = j;
				}
			}

			int temp = array[slot];
			array[slot] = array[i];
			array[i] = temp;

			unsortedness += (slot - i);
		}
		return unsortedness;
	}
}