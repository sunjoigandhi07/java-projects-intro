
//I worked with Nora, Yulia, Saroja, Colton 
import java.util.Scanner;
import java.io.FileNotFoundException;
import java.io.File;
import java.io.RandomAccessFile;
import java.io.IOException;

public class Driver {

	public static void main(String[] args) {

		int fileArray[] = new int[100];
		System.out.println("Please provide a file name. Thanksssss");
		Scanner kb = new Scanner(System.in);
		String fileName = kb.next();

		try {
			RandomAccessFile raf = new RandomAccessFile(fileName, "r");
			int fileLength = raf.readInt();
			int array[] = new int[fileLength];

			for (int i = 0; i < fileLength; i++) {
				array[i] = raf.readInt();
			}
			for (int j = 0; j < fileLength; j++) {
				System.out.println(array[j]);
			}

			System.out.println("Unsortedness : " + Sorting.selectionSort(array));

			Sorting.selectionSort(array);

			System.out.println("------------");

			for (int i = 0; i < fileLength; i++) {
				System.out.println("Could not find file");
			}
			raf.close();
		} catch (Exception e) {
			System.out.println("Could not find file");
		}
	}
}
