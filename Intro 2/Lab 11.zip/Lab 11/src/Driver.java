//I worked with Yulia & Nora on this lab. 

import java.io.RandomAccessFile;
import java.io.IOException;
import java.awt.Color;
import java.util.Scanner;
import edu.du.dudraw.DUDraw;

public class Driver {
	public static void main(String[] args) {
		Scanner input = null;

		System.out.println("Hello, what is the name of your file?");

		Scanner kb = new Scanner(System.in);
		String nameOfFile = kb.nextLine();

		Color[][] imageFile;

		try {
			imageFile = BMPIO.readBMPFile(nameOfFile);
			DUDraw.setCanvasSize(imageFile[0].length, imageFile.length);
			DUDraw.setXscale(0, imageFile[0].length);
			DUDraw.setYscale(0, imageFile.length);
			DUDraw.enableDoubleBuffering();
			for (int i = 0; i < imageFile.length; i++) {
				for (int j = 0; j < imageFile[0].length; j++) {
					DUDraw.setPenColor(imageFile[i][j]);
					DUDraw.filledRectangle(j, i, 0.5, 0.5);
				}
			}
			DUDraw.show();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}