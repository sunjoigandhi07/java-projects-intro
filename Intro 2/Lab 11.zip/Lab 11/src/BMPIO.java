import java.io.RandomAccessFile;
import java.awt.Color;
import java.io.IOException;

public class BMPIO {
	public static Color[][] readBMPFile(String fileName) throws IOException {
		RandomAccessFile raf = null;
		raf = new RandomAccessFile(fileName, "r");

		// check to see if byte 0 is the character 'B'
		raf.seek(0);
		byte firstChar = raf.readByte();
		if (firstChar != 'B') {
			return null;
		}

		// check to see if byte 1 is the character 'M'
		raf.seek(1);
		byte secondChar = raf.readByte();
		if (secondChar != 'M') {
			return null;
		}

		// check to see if offset integer is 54
		raf.seek(10);
		int firstInt = raf.readInt();
		firstInt = Integer.reverseBytes(firstInt);
		if (firstInt != 54) {
			return null;
		}

		// check to see if rest of header value is 40
		raf.seek(14);
		int secondInt = raf.readInt();
		secondInt = Integer.reverseBytes(secondInt);
		if (secondInt != 40) {
			return null;
		}

		// get the width in pixels
		raf.seek(18);
		int width = raf.readInt();
		width = Integer.reverseBytes(width);
		if (width % 4 != 0) {
			return null;
		}

		// get the height in pixels
		raf.seek(22);
		int height = raf.readInt();
		height = Integer.reverseBytes(height);

		// check if bits per pixel is 24
		raf.seek(28);
		short thirdInt = raf.readShort();
		thirdInt = Short.reverseBytes(thirdInt);
		if (thirdInt != 24) {
			return null;
		}

		// go through the rest of the file to draw a picture
		raf.seek(54);
		Color[][] image = new Color[height][width];
		for (int i = 0; i < height; i++) {
			for (int j = 0; j < width; j++) {
				int blue = raf.readUnsignedByte();
				int green = raf.readUnsignedByte();
				int red = raf.readUnsignedByte();

				image[i][j] = new Color(red, green, blue);
			}
		}
		raf.close();
		return image; 
	}
}