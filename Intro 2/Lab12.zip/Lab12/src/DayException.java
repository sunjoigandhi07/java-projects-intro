
public class DayException extends Exception {
	public DayException() {
		super("DayException. That is not a real date stoopid!");
	}
}
