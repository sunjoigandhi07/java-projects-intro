
public class MonthException extends Exception {
	public MonthException() {
		super("MonthException. That is not a real month stoopid! The value must be between 1-12"); 
	}
}
