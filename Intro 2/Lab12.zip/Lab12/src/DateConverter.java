//I worked with Saroja, Yulia, & Nora 
import java.util.Scanner;

public class DateConverter {
	public static void main(String[] args) throws MonthException, DayException {

		System.out.println("Enter an integer representing the month: ");
		Scanner kb = new Scanner(System.in);
		int month = kb.nextInt();
		
		System.out.println("Enter an integer representing the day: ");
		int day = kb.nextInt();
		
		System.out.println(convert(month, day));
		
		System.out.println("Do you want to convert another date? Enter Y or N");
		String userInput = kb.next();

		while(userInput.equals("Y") || userInput.equals("y")) {
			System.out.println("Enter an integer representing the month: ");
			month = kb.nextInt(); 
			
			System.out.println("Enter an integer representing the day: ");
			day = kb.nextInt(); 
			
			System.out.println(convert(month, day)); 
			
			System.out.println("Do you want to convert another date? Enter Y or N");
			userInput = kb.next();
		}
	}

	public static String convert(int month, int day) throws MonthException, DayException {
		if (month < 1 || month > 12) {
			throw new MonthException();
		}
		
		// checks January date
		if (month == 1 && day < 1 || day > 32) {
			throw new DayException();
		} else if (month == 1 && day > 1 && day < 32) {
			return "January " + day;
		}

		// checks February date
		if (month == 2 && day < 1 || day > 29) {
			throw new DayException();
		} else if (month == 2 && day > 1 && day < 29) {
			return "February " + day;
		}

		// checks March date
		if(month == 3 && day < 1 || day > 32) {
			throw new DayException();
		} else if(month == 3 && day > 1 && day < 32) {
			return "March " + day;
		}

		// check April date
		if (month == 4 && day < 1 || day > 31) {
			throw new DayException();
		} else if (month == 4 && day < 1 && day < 31) {
			return "April " + day;
		}

		// checks May date
		if (month == 5 && day < 1 || day > 32) {
			throw new DayException();
		} else if (month == 5 && day > 1 && day < 32) {
			return "May " + day;
		}

		// checks June date
		if (month == 6 && day < 1 || day > 31) {
			throw new DayException();
		} else if (month == 6 && day > 1 && day < 31) {
			return "June " + day;
		}

		// checks July date
		if (month == 7 && day < 1 || day > 32) {
			throw new DayException();
		} else if (month == 7 && day > 1 && day < 32) {
			return "July " + day;
		}

		// checks August date
		if (month == 8 && day < 1 || day > 32) {
			throw new DayException();
		} else if (month == 8 && day > 1 && day < 32) {
			return "August " + day;
		}

		// check September date
		if (month == 9 && day < 1 || day > 31) {
			throw new DayException();
		} else if (month == 9 && day > 1 && day < 31) {
			return "September " + day;
		}

		// check October date
		if (month == 10  && day < 1 || day > 32) {
			throw new DayException();
		} else if (month == 10 && day > 1 && day < 32) {
			return "October " + day;
		}

		// check November date
		if (month == 11 && day < 1 || day > 31) {
			throw new DayException();
		} else if (month == 11 && day > 1 && day < 31) {
			return "November " + day;
		}

		// check December date
		if (month == 12 && day < 1 || day > 32) {
			throw new DayException();
		} else if (month == 12 && day > 1 && day < 32) {
			return "December " + day;
		}

		return "Not a real date, stoopid!";
	}
}