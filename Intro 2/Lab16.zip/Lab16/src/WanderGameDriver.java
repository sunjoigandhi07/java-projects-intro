//I worked with Yulia, Colton, and Nora 

public class WanderGameDriver {

	public static void main(String[] args) {
		WanderGame game = new WanderGame(); 

	}

}
