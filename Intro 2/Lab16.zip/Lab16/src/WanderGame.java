//I worked with Yulia, Colton, and Nora 

import edu.du.dudraw.DrawListener;
import edu.du.dudraw.Draw;
import java.awt.Color;
import java.util.ArrayList;

public class WanderGame implements DrawListener {
	private double xPos;
	private double yPos;
	private double size;
	private Color color;

	private Draw canvas;
	ArrayList<Food> foodPell;
	static final double speed = 0.01;

	public WanderGame() {
		this.size = 0.05;
		color = Color.BLUE;
		canvas = new Draw();
		canvas.setCanvasSize(500, 500);
		canvas.addListener(this);
		canvas.enableDoubleBuffering();

		foodPell = new ArrayList<Food>();
		for (int i = 0; i < 50; i++) {
			foodPell.add(new Food());
		}
		draw();
	}

	public class Food {
		private double foodX;
		private double foodY;
		private double size;

		// constructor
		public Food() {
			this.size = 0.02;
			this.foodX = Math.random();
			this.foodY = Math.random();
		}

		// draw method
		public void draw() {
			canvas.setPenColor(Draw.RED);
			canvas.filledCircle(foodX, foodY, size);
		}
	}

	@Override
	public void keyTyped(char key) {
		// moves player based on which key typed
		if (key == 'w') {
			yPos += speed;
		} else if (key == 'a') {
			xPos -= speed;
		} else if (key == 's') {
			yPos -= speed;
		} else if (key == 'd') {
			xPos += speed;
		} else if (key == 'q') {
			System.exit(0);
		}
		for (int i = 0; i < foodPell.size(); i++) {
			Food food = foodPell.get(i);
			double x = food.foodX;
			double y = food.foodY;

			double dx = Math.abs(xPos - x);
			double dy = Math.abs(yPos - y);
			double s = size + food.size;

			if (dx <= s && dy <= s) {
				size += 0.005;
				color = new Color((int) (Math.random() * 255), (int) (Math.random() * 255),
						(int) (Math.random() * 255));

				foodPell.remove(i);
			}
		}
		draw();
	}

	@Override
	public void mouseClicked(double mouseX, double mouseY) {
		if (mouseX == xPos && mouseY == yPos) {
			canvas.setPenColor(Draw.MAGENTA);
		}

	}

	// drawing the player & food
	public void draw() {
		canvas.clear();
		canvas.setPenColor(color);
		canvas.filledCircle(xPos, yPos, size);
		for (int i = 0; i < foodPell.size(); i++) {
			foodPell.get(i).draw();
		}
		canvas.show();
	}

	@Override
	public void mouseDragged(double arg0, double arg1) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mousePressed(double arg0, double arg1) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseReleased(double x, double y) {

	}

	@Override
	public void update() {
		// TODO Auto-generated method stub
	}

	@Override
	public void keyPressed(int arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void keyReleased(int arg0) {
		// TODO Auto-generated method stub

	}
}
