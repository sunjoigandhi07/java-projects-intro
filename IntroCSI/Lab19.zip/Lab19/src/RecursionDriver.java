//I worked Colton, Nora, and Saroja 

public class RecursionDriver {

	public static void main(String[] args) {
		//Recursion.drawCircles(0.5, 0.5, 0.2, 5);

		Recursion.drawTreeRecursive(5, 0.5, 0.5,0.1, Math.PI/2); 
	}

}
