//I worked with Saroja, Nora, Paulina, and Colton 

public class RecursionDriver {

	public static void main(String[] args) {
		//test sumOfSquares 
		System.out.println(Recursion.sumOfSquares(10)); 

		//test Fibonacci 
		System.out.println(Recursion.fib(8)); 
	}
}
