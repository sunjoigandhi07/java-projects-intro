//I worked with Paulina, Colton, Nora, and Saroja 

public class Recursion {

	public static int sumOfSquares(int k) {
		if(k <= 0) {
			return 0; 
		}
		return (k*k) + sumOfSquares(k-1); 
	}
	
	public static int fib(int n) {
		if(n <=1) {
			return 1; 
		}
		
		return fib(n-1) + fib(n-2); 
		
	}
}
