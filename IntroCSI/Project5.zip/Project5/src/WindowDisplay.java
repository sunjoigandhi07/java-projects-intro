import java.util.ArrayList;
import java.util.Collections;
import java.awt.Color;
import edu.du.dudraw.Draw;
import edu.du.dudraw.DrawListener;

public class WindowDisplay implements DrawListener {
	private ArrayList<Window> box;
	private Draw canvas;
	double lastX;
	double lastY; 

	// constructor for WindowDisplay
	public WindowDisplay(int x, int y) {
		canvas = new Draw();
		canvas.setCanvasSize(x, y);
		canvas.setXscale(0, x);
		canvas.setYscale(0, y);
		canvas.addListener(this);

		box = new ArrayList<Window>();
		canvas.enableDoubleBuffering(); 
	}

	// method that creates a new window object and adds it to the arrayList
	public void addWindow(double x, double y, double w, double h, Color c) {
		Window newWindow = new Window(x, y, w, h, c, box.size());

		box.add(newWindow);
	}

	// method that draws all the windows
	public void draw() {
		canvas.clear(); 
		for (int i = 0; i < box.size(); i++) {
			box.get(i).draw();
		}
		canvas.show(); 
	}

	public void reset() {
		Collections.sort(box);
		for(int i = 0; i < box.size(); i ++) {
			Window start = box.get(i); 
			 start.xPos =  start.initialX; 
			 start.yPos = start.initialY; 
		}
	}

	// inner class
	public class Window implements Comparable<Window> {
		private double initialX;
		private double initialY;
		private double xPos;
		private double yPos;
		private int index; 
		private double width;
		private double height;
		private Color color;

		// constructor for Window
		public Window(double x, double y, double w, double h, Color c, int i) { 
			this.initialX = x; 
			this.initialY = y; 
			this.xPos = x;
			this.yPos = y;
			this.index = i;  
			this.width = x;
			this.height = h;
			this.color = c;
		}

		// draws a single window
		public void draw() {
			canvas.setPenColor(color);
			canvas.filledRectangle(xPos, yPos, width, height);
		}

		// checks if where x & y coordinates are within the window
		public boolean isWithin(double x, double y) {
			if (x > (xPos - width / 2) && x < (xPos + width / 2) && y > (yPos - height / 2) && y < (yPos + width / 2)) {
				return true;
			}
			return false;
		}
		
		//
		@Override
		public int compareTo(Window o) {
			return 	index - o.index;
		}
	}
	
	//when certain keys are pressed, either quit or reset screen 
	@Override
	public void keyTyped(char key) {
		if (key == 'R' || key == 'r') {
			reset();
		} else if (key == 'Q' || key == 'q') {
			System.exit(0);
		}

	}
	
	//when is window is clicked, it moves to the top 
	@Override
	public void mousePressed(double x, double y) {
		int boxIndex = -1;
		lastX = x; 
		lastY = y; 
		for (int i = 0; i < box.size(); i++) {
			if (box.get(i).isWithin(x, y)) {
				boxIndex = i;
			}
		}
		if (boxIndex >= 0) {
			Window top = box.get(boxIndex);
			box.remove(top);
			box.add(top);
		}
		draw(); 
	}
	
	// dragging a window across the screen 
	@Override
	public void mouseDragged(double x, double y) {
		for(int i = box.size()-1; i >= 0; i --) {
			Window move = box.get(i); 
			if(move.isWithin(x,y)) {
				move.xPos -= lastX - x; 
				move.yPos -= lastY -y; 
	
				//terminates the loop early 
				break;
			}
		}
		lastX = x; 
		lastY = y; 
		draw(); 
	}
	
	// continuously draws the windows 
	@Override
	public void update() {
		draw();
	}

	//draw listener required methods 
	@Override
	public void keyPressed(int arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void keyReleased(int arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseClicked(double arg0, double arg1) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseReleased(double arg0, double arg1) {
		// TODO Auto-generated method stub

	}
}
