import java.awt.Color;

public class WindowDriver {

	public static void main(String[] args) {
		WindowDisplay test = new WindowDisplay(600,600); 
		
		test.addWindow(50, 50, 60, 80, Color.BLUE);

		test.addWindow(100, 130, 80, 80, Color.RED);

		test.addWindow(80, 80, 60, 80, Color.GREEN);

		test.addWindow(120, 60, 100, 80, Color.BLACK);
	}

}
